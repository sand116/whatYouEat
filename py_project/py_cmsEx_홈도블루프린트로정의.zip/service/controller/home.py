from flask import Flask, render_template, redirect, url_for, session, request, jsonify, make_response
from service.controller import bp_home as app
# 디비
from service.model import dbHelper
from service import config

@app.route('/')
def home():
    resp = make_response(render_template('index.html', config=config) )
    # 쿠키 세팅
    resp.set_cookie('uid', session['uid'])
    return resp