-LAN Icons-
An idea coined by the icon designer(s) over at PixelPress, but
reimplimented by yours truely. i like that users can create their
own icons to fit the need. tre cool.

PIXELPRESS URL:
http://www.golden.net/%7Eggehiere/pixelpress/index.html

NOTE: This scheme is best used with Microangelo, and Any Folder.

Also included are system "file type" icons, which is a little more complex.
To use these effectively, simply click on "view" (which is on almost any 
window), and select "options..."
Now select the tab "File Types" - - and then select a file type
who's icon you wish to change.
This list may help you properly place each icon has it is intended:

*CHANGE ONLY THE ICONS IN "FILE TYPES", TAMPERING WITH ANY OTHER DATA CAN DAMAGE YOUR REGISTRY*

^Dont be scared of this warning, just use common sense....and then you are set.


COPYRIGHTS-----
This scheme design was solely created by COPLAND, as were ALL! of the icons.
This is, as is all of MY software, Freeware, so distribute this freely...
w/ MY PERMISSION. just keep its contents of this zip file, including 
this text, unaltered, and uncommercial. if you have any questions, see the
copyrights information page at my website.
>http://members.xoom.com/copland_icon/right.html

If you wish to contact me:

EMAIL: copland@cybergal.com 
URL: http://members.xoom.com/copland_icon/